from pymavlink import mavutil
import time
import GS_example
import Servo_example_3Servo_Move
# 配置参数
# SERIAL_PORT = '/dev/ttyUSB0'  # 数传串口（Windows可能为'COM3'等）
# BAUD_RATE = 57600  # 数传波特率（需与飞控一致）
SWITCH_CHANNEL = 5
SWITCH_THRESHOLD = 1500


# def connect_to_vehicle():
#     """连接到飞控"""
#     print(f"连接到飞控 {SERIAL_PORT}...")
#     vehicle = mavutil.mavlink_connection(
#         SERIAL_PORT,
#         baud=BAUD_RATE,
#         autoreconnect=True
#     )
#     # 等待心跳包
#     vehicle.wait_heartbeat()
#     print("成功连接到飞控！")
#     return vehicle

def get_switch_position(vehicle):
    # request for controller's channel data
    vehicle.mav.request_data_stream_send(
        vehicle.target_system,
        vehicle.target_component,
        mavutil.mavlink.MAV_DATA_STREAM_ALL,
        1, 1
    )
    # get data from channel
    msg = vehicle.recv_match(type='RC_CHANNELS', blocking=True, timeout=1)
    if msg:
        # get the pwm value from channel
        channels = [msg.chan1_raw, msg.chan2_raw, msg.chan3_raw,
                    msg.chan4_raw, msg.chan5_raw, msg.chan6_raw]
        return channels[SWITCH_CHANNEL]
    return 0  # for timeout


def send_manual_control(vehicle, roll, pitch, throttle, yaw):
    # send message to MAVLink manually
    # limit pwm value into valid range
    roll = max(1000, min(2000, roll))
    pitch = max(1000, min(2000, pitch))
    throttle = max(1000, min(2000, throttle))
    yaw = max(1000, min(2000, yaw))

    vehicle.mav.manual_control_send(
        vehicle.target_system,
        roll,
        pitch,
        throttle,
        yaw,
    )

if __name__ == "__main__":
    vehicle = GS_example.connect_to_cube()
    try:
        while True:
            # get position of controller
            switch_pos = get_switch_position(vehicle)

            if switch_pos > SWITCH_THRESHOLD:
                mav = GS_example.connect_to_cube()
                controller = Servo_example_3Servo_Move.ServoController(mav)
                controller.write_servo_params()

                # Example: Move servo to 30 degrees
                print("control by python code,sending command")
                controller.send_angle(30)
            else:
                print("control by controller, sending command.")
            # control frequency 10Hz
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("program stopped by keyboard")
    finally:
        # when program stopped, return each axis to neutral.
        send_manual_control(vehicle, 1500, 1500, 1000, 1500)
        print("connection lost.")
